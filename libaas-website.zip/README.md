# Libaas – Pakistani Designer Suits

A simple one-page website for selling stitched Pakistani designer suits: lawn, formal, winter and bridal wear. Customers browse the collection, filter by type and order on WhatsApp.

Live site: `https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/`

## Features

- Photo cards for every suit, with name, fabric, occasion and price in PKR
- Filter buttons: Lawn, Formal, Winter, Bridal
- "Order on WhatsApp" button that sends the suit name and price in the message
- Works on mobile and desktop
- No build step and no dependencies: one HTML file and a folder of photos

## Files

```
index.html     the whole website
images/        suit photos (one per suit)
README.md      this file
```

## GitHub Pages par publish karna

1. GitHub par repository banayein aur `index.html`, `README.md` aur poora `images` folder upload karein.
2. Repository ki **Settings → Pages** mein jayein.
3. Source mein **Deploy from a branch** chunein, branch `main` aur folder `/ (root)` select karke **Save** karein.
4. 1 se 2 minute baad site upar diye gaye link par live hogi.

## WhatsApp number badalna

`index.html` kholein aur `// ===== EDIT THESE =====` dhoondein. Neeche `WHATSAPP` mein apna number likhein: country code ke sath, bina `+` aur bina space ke.

```js
var WHATSAPP = "923001234567";
```

## Naya suit add karna

1. Suit ki photo `images` folder mein upload karein (e.g. `meher.jpg`).
2. `index.html` mein `DRESSES` list mein aik nayi line add karein:

```js
{n:"Meher Lawn Suit",t:"Lawn",f:"3 piece: embroidered shirt, dupatta, trouser",o:"Summer. Sizes S to XL.",p:7500,i:"meher.jpg",c:["#1b2559","#e0a526"]},
```

| Field | Matlab |
|-------|--------|
| `n` | suit ka naam |
| `t` | type (Lawn, Formal, Winter, Bridal). Nayi type likhein to nayi filter button khud ban jati hai |
| `f` | kapra aur kitne piece |
| `o` | occasion aur sizes |
| `p` | price (sirf number, Rs. khud lag jata hai) |
| `i` | photo ka naam `images` folder se |
| `c` | do rang, jo photo na milne par pattern mein dikhte hain |

Kisi suit ko hatane ke liye us ki puri line delete kar dein.

## Photos ke liye tips

- Portrait photos (lambi) sab se acchi lagti hain, tareeban 2:3 ratio.
- Photo ka size 200 KB se kam rakhein taake site tez khule.
- Sirf wohi photos lagayein jo aap ki apni hain ya jin ki ijazat ho.

## Rang aur design badalna

Rang `index.html` ke start mein `:root` ke andar hain (`--indigo`, `--madder`, `--saffron`, `--bone`). Inhein badal dein to poori site ke rang badal jayenge.

## License

Apni marzi ke mutabiq license chunein. Jab tak koi license file nahi lagti, sab haqooq aap ke paas rehte hain.
